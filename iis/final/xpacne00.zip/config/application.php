<?php

	$_APPLICATION = array(
		'session_admin'			=> 'knihovnaadmin',

		'domain_path'			=> '',
		//'domain_path'			=> 'public_html/_sub/iis/',
		'content_path'			=> 'include/content',
		'admin_content_path'	=> 'include/admin',
		'content_extension'		=> 'inc',

		'default_timezone'		=> 'Europe/Prague',

		'sender'				=> 'IIS knihovna <xpacne00@stud.fit.vutbr.cz>',
		'receiver'				=> 'Jan Pacner <xpacne00@stud.fit.vutbr.cz>'
	);

?>
