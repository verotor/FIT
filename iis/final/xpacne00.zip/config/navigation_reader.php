<?php

	$_NAVIGATION_READER = array(
		'index'		=> array(
			'page_name'		=> 'Vyhledávání',
		),
		'tituly'			=> array(
			'page_name'		=> 'Tituly',
		),
		'404'		=> array(
			'page_name'		=> 'Stránka nenalezena'
		)
	);

?>
