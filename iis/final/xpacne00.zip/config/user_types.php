<?php

	define('USER_PUBLIC', 0);
	define('USER_ADMIN', 1);
	define('USER_READER', 2);
	define('USER_LIBRARIAN', 3);

?>
