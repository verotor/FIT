<?php

	$_NAVIGATION = array(
		'index'		=> array(
			'page_name'		=> 'Vyhledávání',
		),
		'404'		=> array(
			'page_name'		=> 'Stránka nenalezena'
		)
	);

?>
