<?php

	$_NAVIGATION_ADMIN = array(
		'index'		=> array(
			'page_name'		=> 'Vyhledávání',
		),
		'sekce'		=> array(
			'page_name'		=> 'Sekce',
		),
		'knihovnici'		=> array(
			'page_name'		=> 'Knihovníci',
		),
		'404'		=> array(
			'page_name'		=> 'Stránka nenalezena'
		)
	);

?>
