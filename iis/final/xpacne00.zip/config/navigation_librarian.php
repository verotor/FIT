<?php

	$_NAVIGATION_LIBRARIAN = array(
		'index'				=> array(
			'page_name'		=> 'Vyhledávání',
		),
		'autori'			=> array(
			'page_name'		=> 'Autoři',
		),
		'vydavatele'		=> array(
			'page_name'		=> 'Vydavatelé',
		),
		'typy_titulu'		=> array(
			'page_name'		=> 'Typy titulů',
		),
		'klicova_slova'		=> array(
			'page_name'		=> 'Klíčová slova',
		),
		'tituly'			=> array(
			'page_name'		=> 'Tituly',
		),
		'ctenari'			=> array(
			'page_name'		=> 'Čtenáři',
		),
		'404'				=> array(
			'page_name'		=> 'Stránka nenalezena'
		)
	);

?>
