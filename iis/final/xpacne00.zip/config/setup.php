<?php

	$_SETUP = array(
		'security'	=> array(
			'login'	=> true
		)
	);

?>
